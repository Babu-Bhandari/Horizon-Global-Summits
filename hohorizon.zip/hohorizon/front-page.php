<?php
/**
 * Homepage.
 *
 * @package Hohorizon
 */

if (!defined('ABSPATH')) {
	exit;
}

get_header();

$video_id  = absint(get_theme_mod('hohorizon_hero_video', 0));
$video_url = $video_id ? wp_get_attachment_url($video_id) : get_template_directory_uri() . '/assets/hero.mp4';
$hero      = hohorizon_hero_still();
$title     = hohorizon_hero_lines();
?>
<section class="hero">
	<div class="hero-bg" style="background-image:url('<?php echo esc_url($hero); ?>')"></div>
	<?php if ($video_url) : ?>
		<video class="hero-video" hidden autoplay muted loop playsinline poster="<?php echo esc_url($hero); ?>">
			<source src="<?php echo esc_url($video_url); ?>" type="video/mp4" />
		</video>
	<?php endif; ?>
	<div class="hero-shade"></div>
	<div class="hero-copy">
		<div class="hero-lead">
			<h1><span><?php echo esc_html($title[0]); ?></span><span><?php echo esc_html($title[1]); ?></span><span><?php echo esc_html($title[2]); ?></span></h1>
			<div class="rule"></div>
			<div class="hero-actions">
				<a class="btn" href="<?php echo esc_url(hohorizon_page_url('become-a-partner')); ?>"><?php echo esc_html(hohorizon_mod('button_partner')); ?></a>
				<a class="btn" href="<?php echo esc_url(hohorizon_page_url('invitation')); ?>"><?php echo esc_html(hohorizon_mod('button_invite')); ?></a>
			</div>
		</div>
	</div>
</section>

<section class="section company-section">
	<?php get_template_part('template-parts/companies'); ?>
	<div class="wrap">
		<article class="about-card">
			<div class="frame">
				<img src="https://images.unsplash.com/photo-1521737711867-e3b97375f902?auto=format&fit=crop&w=1400&q=80" alt="A small group in discussion" />
			</div>
			<div>
				<p class="about-display">About us</p>
				<p class="eyebrow">Who we are</p>
				<h2>A forum for people who can speak for a decision.</h2>
				<p class="lede">HOHORIZON GLOBAL AFFAIRS hosts international business conversations that stay specific, civil and useful. Executives, investors, policymakers and operators sit together with a clear programme and time left for the meeting that does not fit on a panel.</p>
				<div class="about-stats">
					<p><strong data-count="750" data-suffix="+">750+</strong><span>Delegates</span></p>
					<p><strong data-count="300" data-suffix="+">300+</strong><span>Companies represented</span></p>
					<p><strong data-count="60" data-suffix="%">60%</strong><span>C-suite &amp; director-level attendees</span></p>
					<p><strong data-count="25" data-suffix="+">25+</strong><span>Industry speakers</span></p>
					<p><strong data-count="20" data-suffix="+">20+</strong><span>Partners</span></p>
					<p><strong data-count="200" data-suffix="k+">200k+</strong><span>Digital reach</span></p>
				</div>
			</div>
		</article>
	</div>
</section>

<?php hohorizon_speaker_stage('h2', true); ?>

<section class="section paper">
	<div class="wrap">
		<p class="about-display">Media</p>
		<div class="section-head">
			<div>
				<p class="eyebrow"><?php echo esc_html(hohorizon_mod('events_eyebrow')); ?></p>
				<h2><?php echo esc_html(hohorizon_mod('events_title')); ?></h2>
			</div>
			<a class="btn btn-ink" href="<?php echo esc_url(hohorizon_page_url('events')); ?>">All events</a>
		</div>
		<?php hohorizon_event_list(2); ?>
	</div>
</section>

<section class="section">
	<div class="wrap">
		<div class="section-head">
			<div>
				<p class="eyebrow"><?php echo esc_html(hohorizon_mod('programme_eyebrow')); ?></p>
				<h2><?php echo esc_html(hohorizon_mod('programme_title')); ?></h2>
			</div>
			<a class="btn btn-ink" href="<?php echo esc_url(hohorizon_page_url('programme')); ?>">Full programme</a>
		</div>
		<p class="lede" style="margin-bottom:22px"><?php echo esc_html(hohorizon_mod('programme_note')); ?></p>
		<?php hohorizon_filters(); ?>
		<?php
		$sessions = hohorizon_query('hoh_session', 4);
		while ($sessions->have_posts()) {
			$sessions->the_post();
			hohorizon_session_row();
		}
		wp_reset_postdata();
		?>
	</div>
</section>

<?php $topics = hohorizon_query('hoh_topic'); ?>
<?php if ($topics->have_posts()) : ?>
	<section class="section paper">
		<div class="wrap topics">
			<div class="section-head">
				<div>
					<p class="eyebrow"><?php echo esc_html(hohorizon_mod('topics_eyebrow')); ?></p>
					<h2><?php echo esc_html(hohorizon_mod('topics_title')); ?></h2>
				</div>
			</div>
			<?php $number = 1; ?>
			<?php while ($topics->have_posts()) : $topics->the_post(); ?>
				<article class="topic">
					<?php $image = hohorizon_image_url(get_the_ID()); ?>
					<?php if ($image) : ?><img src="<?php echo esc_url($image); ?>" alt="" /><?php endif; ?>
					<div>
						<p class="eyebrow"><?php echo esc_html(str_pad((string) $number, 2, '0', STR_PAD_LEFT)); ?></p>
						<h2><?php the_title(); ?></h2>
						<p class="lede" style="margin-top:14px"><?php echo esc_html(wp_strip_all_tags(get_the_content())); ?></p>
						<?php $related = get_post_meta(get_the_ID(), '_hohorizon_related', true); ?>
						<?php if ($related) : ?><p class="lede"><?php echo esc_html($related); ?></p><?php endif; ?>
					</div>
				</article>
				<?php $number++; ?>
			<?php endwhile; ?>
			<?php wp_reset_postdata(); ?>
		</div>
	</section>
<?php endif; ?>

<section class="section paper">
	<div class="wrap">
		<div class="section-head">
			<div>
				<p class="eyebrow"><?php echo esc_html(hohorizon_mod('partners_eyebrow')); ?></p>
				<h2><?php echo esc_html(hohorizon_mod('partners_title')); ?></h2>
			</div>
			<a class="btn btn-ink" href="<?php echo esc_url(hohorizon_page_url('partners')); ?>">Partner page</a>
		</div>
		<?php hohorizon_partner_row(4); ?>
	</div>
</section>

<section class="section">
	<div class="wrap split">
		<div>
			<p class="eyebrow"><?php echo esc_html(hohorizon_mod('member_eyebrow')); ?></p>
			<h2><?php echo esc_html(hohorizon_mod('member_title')); ?></h2>
			<p class="lede" style="margin-top:18px"><?php echo esc_html(hohorizon_mod('member_text')); ?></p>
			<ul class="lede" style="margin-top:16px;padding-left:18px">
				<?php foreach (hohorizon_lines(hohorizon_mod('member_points')) as $point) : ?>
					<li><?php echo esc_html($point); ?></li>
				<?php endforeach; ?>
			</ul>
			<div class="actions">
				<a class="btn btn-ink" href="<?php echo esc_url(hohorizon_page_url('membership')); ?>">Become a member</a>
				<a class="btn btn-ink" href="<?php echo esc_url(hohorizon_page_url('become-a-partner')); ?>"><?php echo esc_html(hohorizon_mod('button_partner')); ?></a>
			</div>
		</div>
		<div class="frame">
			<img src="<?php echo esc_url(hohorizon_mod('member_image')); ?>" alt="" />
		</div>
	</div>
</section>

<section class="cta" style="background-image:url('<?php echo esc_url(hohorizon_mod('cta_image')); ?>')">
	<div class="wrap">
		<p class="eyebrow"><?php echo esc_html(hohorizon_mod('cta_eyebrow')); ?></p>
		<h2><?php echo esc_html(hohorizon_mod('cta_title')); ?></h2>
		<p class="lede" style="margin-top:16px;color:rgba(251,250,247,.86)"><?php echo esc_html(hohorizon_mod('cta_text')); ?></p>
		<div class="actions"><a class="btn" href="<?php echo esc_url(hohorizon_page_url('invitation')); ?>">Request an invitation</a></div>
	</div>
</section>
<?php
get_footer();
