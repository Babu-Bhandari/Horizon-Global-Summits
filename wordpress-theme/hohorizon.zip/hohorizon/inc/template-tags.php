<?php
/**
 * Template helpers.
 *
 * @package Hohorizon
 */

if (!defined('ABSPATH')) {
	exit;
}

/**
 * Default text used until a Customizer value is saved.
 *
 * @return array<string, string>
 */
function hohorizon_defaults() {
	return array(
		'line1'            => 'Horizon',
		'line2'            => 'Global',
		'line3'            => 'Summits',
		'mark'             => 'Forum',
		'button_partner'   => 'Partner With Us',
		'button_invite'    => 'Explore Our Summits',
		'hero_title'       => 'Expanding Horizons Uniting Global Minds',
		'hero_name'        => 'Horizon Global Affairs',
		'hero_date'        => 'Date to be confirmed.',
		'hero_venue'       => 'Venue to be confirmed.',
		'hero_side'        => "One focused day.\nFive live streams.",
		'streams'          => 'Finance, Risk, Trade, Technology, Leadership',
		'countdown'        => '',
		'hero_image'       => '',
		'intro_image'      => 'https://images.unsplash.com/photo-1511578314322-379afb476865?auto=format&fit=crop&w=2000&q=80',
		'welcome_eyebrow'  => 'Welcome to Horizon',
		'welcome_title'    => 'Where global leaders connect and opportunities begin.',
		'welcome_text'     => "Horizon GLOBAL AFFAIRS is a forum, not a trade-show floor. It is built for people who already carry responsibility: the executive opening a new market, the investor testing a thesis, the policymaker who needs the view from the operating table.\n\nThe purpose is simple. Put the right people in one place, give them a clear programme, and leave enough time for the conversation that does not fit on a panel.",
		'welcome_image'    => 'https://images.unsplash.com/photo-1511578314322-379afb476865?auto=format&fit=crop&w=1400&q=80',
		'stats_eyebrow'    => 'The room, in numbers',
		'stats_title'      => 'Figures will be published when they are real.',
		'stats'            => "International delegates | To be confirmed | Placeholder\nParticipating companies | To be confirmed | Placeholder\nCountries represented | To be confirmed | Placeholder\nIndustry leaders | To be confirmed | Placeholder\nStrategic partners | To be confirmed | Placeholder\nGlobal reach | To be confirmed | Placeholder",
		'expect_eyebrow'   => 'What to expect',
		'expect_title'     => 'A day built around the conversation.',
		'events_eyebrow'   => 'Upcoming',
		'events_title'     => 'Gatherings on the calendar will appear here.',
		'programme_eyebrow'=> 'Sample agenda',
		'programme_title'  => 'The programme is not confirmed yet.',
		'programme_note'   => 'The rows below show the layout. Times, speakers and titles are placeholders.',
		'topics_eyebrow'   => 'Discussion areas',
		'topics_title'     => 'Five subjects. No filler track.',
		'speakers_eyebrow' => 'Speakers',
		'speakers_title'   => 'Names will be published when they are confirmed.',
		'partners_eyebrow' => 'Partners',
		'partners_title'   => 'Logo places, ready to be replaced.',
		'member_eyebrow'   => 'Membership & partnership',
		'member_title'     => 'A seat, or a role in the room.',
		'member_text'      => 'Members come for the conversations and the introductions. Partners help shape the gathering and meet the people in it. Fees, if any, will be published when each opens. Nothing on this page is an offer.',
		'member_points'    => "International networking with a host, not a directory.\nA path to executive conversations around the programme.\nVisibility only where it is agreed in advance.",
		'member_image'     => 'https://images.unsplash.com/photo-1556761175-b413da4baf72?auto=format&fit=crop&w=1400&q=80',
		'cta_eyebrow'      => 'Invitation',
		'cta_title'        => 'Your next global connection starts here.',
		'cta_text'         => '',
		'cta_image'        => 'https://images.unsplash.com/photo-1540575467063-178a50c2df87?auto=format&fit=crop&w=2000&q=80',
		'footer_text'      => 'To build influential global platforms that bring business leaders together, foster cross-industry connections, and transform meaningful dialogue into strategic partnerships, valuable opportunities, and sustainable business impact.',
		'public_email'     => 'connect@horizonglobalsummits.com',
		'venue'            => 'Venue to be confirmed',
		'office'           => 'Dubai, United Arab Emirates',
		'hours'            => '09:30 AM to 5:30 PM GST (UTC+4)',
		'phone'            => 'To be confirmed',
		'inbox'            => 'connect@horizonglobalsummits.com',
		'ga'               => '',
		'linkedin'         => 'https://www.linkedin.com/company/horizon-global-summits/',
		'instagram'        => '',
		'youtube'          => '',
		'facebook'         => '',
	);
}

/**
 * A Customizer value, or its default.
 *
 * @param string $key Key without the hohorizon_ prefix.
 * @return string
 */
function hohorizon_mod($key) {
	$defaults = hohorizon_defaults();
	$default  = isset($defaults[$key]) ? $defaults[$key] : '';
	$value    = get_theme_mod('hohorizon_' . $key, $default);
	$value    = is_string($value) ? $value : $default;
	$retired  = array(
		'xxxxx@horizonglobalsummits.com',
		'To be confirmed',
		'Venue to be confirmed',
		'CWFZ0398, Compass Building. Al Shohada Road, Al Hamra industrial Zone-FZ, Ras Al Khaimah. United Arab Emirates',
		'CWFZ0398, Compass Building, Ras Al Khaimah, United Arab Emirates',
		'An invitation-led forum for executives, investors, policymakers and operators who need a quieter room for serious conversations.',
		'Join an international community of business leaders and decision-makers. Applications are read. An invitation is sent only when a place is confirmed.',
	);
	if ($value === '' || in_array($value, $retired, true)) {
		$value = $default;
	}
	if ($key === 'linkedin') {
		return $default;
	}
	if (in_array($key, array('public_email', 'inbox'), true) && preg_match('/^x+@/i', $value)) {
		$value = $default;
	}
	return hohorizon_brand_name($value);
}

/**
 * Show the public name as Horizon wherever older copy still says HOHORIZON.
 *
 * @param string $text Text.
 * @return string
 */
function hohorizon_brand_name($text) {
	if (!is_string($text)) {
		return $text;
	}
	return str_replace(array('HOHORIZON', 'Hohorizon'), 'Horizon', $text);
}
add_filter('the_title', 'hohorizon_brand_name');
add_filter('the_content', 'hohorizon_brand_name');

/**
 * Hero still shown before the film plays.
 *
 * @return string
 */
function hohorizon_hero_still() {
	$image = hohorizon_mod('hero_image');
	if ($image === '' || strpos($image, 'photo-1464037866556') !== false) {
		return get_template_directory_uri() . '/assets/hero-still.jpg';
	}
	return $image;
}

/**
 * The three hero title lines.
 *
 * @return array<int, string>
 */
function hohorizon_hero_lines() {
	$defaults = hohorizon_defaults();
	$lines    = array();
	foreach (array('line1', 'line2', 'line3') as $key) {
		$default = isset($defaults[$key]) ? $defaults[$key] : '';
		$value   = get_theme_mod('hohorizon_' . $key, $default);
		$lines[] = is_string($value) ? $value : $default;
	}
	if ($lines === array('HOHORIZON', 'GLOBAL', 'AFFAIRS') || $lines === array('Horizon', 'GLOBAL', 'AFFAIRS')) {
		return array('Horizon', 'Global', 'Summits');
	}
	return array_map('hohorizon_brand_name', $lines);
}

/**
 * Menu icon for a label.
 *
 * @param string $label Menu label.
 * @return string
 */
function hohorizon_nav_icon($label) {
	$key   = strtolower(trim(wp_strip_all_tags($label)));
	$paths = array(
		'home'              => '<path d="M4 10.5 12 4l8 6.5V20a1 1 0 0 1-1 1h-5v-6H10v6H5a1 1 0 0 1-1-1z"/>',
		'about'             => '<circle cx="12" cy="8" r="3"/><path d="M5 19c1.2-3 3.4-4.5 7-4.5S17.8 16 19 19"/>',
		'conference'        => '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M8 3v4M16 3v4M7 11h10M12 11v5"/>',
		'agenda'            => '<rect x="4" y="5" width="16" height="15" rx="2"/><path d="M8 3v4M16 3v4M4 10h16"/>',
		'speakers'          => '<rect x="9" y="3" width="6" height="10" rx="3"/><path d="M6 11a6 6 0 0 0 12 0M12 17v4M8 21h8"/>',
		'partners'          => '<circle cx="8" cy="9" r="2.4"/><circle cx="16" cy="9" r="2.4"/><path d="M3.5 18.5c.7-2.4 2.3-3.5 4.5-3.5s3.8 1.1 4.5 3.5M11.5 18.5c.7-2.4 2.3-3.5 4.5-3.5s3.8 1.1 4.5 3.5"/>',
		'media'             => '<rect x="3" y="6" width="18" height="12" rx="2"/><path d="m10 9 5 3-5 3z"/>',
		'contact'           => '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="m4 7 8 6 8-6"/>',
		'our mission'       => '<circle cx="12" cy="12" r="8"/><path d="M12 8v4l3 2"/>',
		'membership'        => '<rect x="3" y="6" width="18" height="12" rx="2"/><path d="M3 10h18"/>',
		'become a partner'  => '<path d="M12 5v14M5 12h14"/>',
	);
	$path = isset($paths[$key]) ? $paths[$key] : $paths['home'];
	return '<svg class="nav-icon" viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round">' . $path . '</svg>';
}

/**
 * Permalink for a page slug created by the theme.
 *
 * @param string $slug Page slug.
 * @return string
 */
function hohorizon_page_url($slug) {
	$aliases = array(
		'terms'          => array('terms', 'terms-and-conditions', 'terms-conditions'),
		'privacy'        => array('privacy', 'privacy-policy'),
		'cookies'        => array('cookies', 'cookie-policy'),
		'manage-cookies' => array('manage-cookies'),
	);
	$names = isset($aliases[$slug]) ? $aliases[$slug] : array($slug);
	foreach ($names as $name) {
		$page = get_page_by_path($name);
		if ($page) {
			return get_permalink($page);
		}
	}
	if (function_exists('hohorizon_legal_page_targets')) {
		$targets = hohorizon_legal_page_targets();
		if (isset($targets[$slug])) {
			$pages = hohorizon_find_legal_pages($targets[$slug]);
			if ($pages) {
				return get_permalink($pages[0]);
			}
		}
	}
	return home_url('/' . trim($slug, '/') . '/');
}

/**
 * Photo for a post: featured image, then a stored URL.
 *
 * @param int    $post_id Post ID.
 * @param string $meta    Meta key.
 * @param string $fallback Fallback URL.
 * @return string
 */
function hohorizon_image_url($post_id, $meta = '_hohorizon_image', $fallback = '') {
	$thumb = get_the_post_thumbnail_url($post_id, 'large');
	if ($thumb) {
		return $thumb;
	}
	$stored = get_post_meta($post_id, $meta, true);
	if (is_string($stored) && $stored !== '') {
		return $stored;
	}
	return $fallback;
}

/**
 * Split a textarea into trimmed lines.
 *
 * @param string $text Raw text.
 * @return string[]
 */
function hohorizon_lines($text) {
	$lines = preg_split('/\r\n|\r|\n/', (string) $text);
	$clean = array();
	foreach ($lines as $line) {
		$line = trim($line);
		if ($line !== '') {
			$clean[] = $line;
		}
	}
	return $clean;
}

/**
 * Stat rows: Label | Value | Note.
 *
 * @return array<int, array{0: string, 1: string, 2: string}>
 */
function hohorizon_stats() {
	$rows = array();
	foreach (hohorizon_lines(hohorizon_mod('stats')) as $line) {
		$parts = array_map('trim', explode('|', $line));
		if (count($parts) < 2 || $parts[0] === '') {
			continue;
		}
		$rows[] = array($parts[0], $parts[1], isset($parts[2]) ? $parts[2] : '');
	}
	return $rows;
}

/**
 * Session topic labels.
 *
 * @return array<string, string>
 */
function hohorizon_topics() {
	return array(
		'finance'    => 'Finance',
		'investment' => 'Investment',
		'trade'      => 'Global trade',
		'technology' => 'Technology',
		'leadership' => 'Leadership',
		'risk'       => 'Risk management',
	);
}

/**
 * Partner tiers.
 *
 * @return array<string, string>
 */
function hohorizon_tiers() {
	return array(
		'strategic'     => 'Strategic partners',
		'platinum'      => 'Platinum partners',
		'gold'          => 'Gold partners',
		'silver'        => 'Silver partners',
		'institutional' => 'Institutional partners',
		'media'         => 'Media partners',
	);
}

/**
 * Query theme content in menu order.
 *
 * @param string $type Post type.
 * @param int    $count How many. -1 for all.
 * @param array  $meta Optional meta query.
 * @return WP_Query
 */
function hohorizon_query($type, $count = -1, $meta = array()) {
	$args = array(
		'post_type'      => $type,
		'posts_per_page' => $count,
		'orderby'        => 'menu_order',
		'order'          => 'ASC',
		'post_status'    => 'publish',
	);
	if ($meta) {
		$args['meta_query'] = $meta;
	}
	return new WP_Query($args);
}

/**
 * Page banner.
 *
 * @param int $post_id Post ID.
 */
function hohorizon_page_hero($post_id = 0) {
	$post_id = $post_id ? $post_id : get_queried_object_id();
	$image   = hohorizon_image_url($post_id, '_hohorizon_hero');
	$eyebrow = get_post_meta($post_id, '_hohorizon_eyebrow', true);
	echo '<section class="page-hero"';
	if ($image) {
		echo ' style="' . esc_attr('--hero:url(' . esc_url($image) . ')') . '"';
	}
	echo '><div class="wrap">';
	if ($eyebrow) {
		echo '<p class="eyebrow">' . esc_html($eyebrow) . '</p>';
	}
	echo '<h1>' . esc_html(get_the_title($post_id)) . '</h1>';
	if (has_excerpt($post_id)) {
		echo '<p>' . esc_html(get_the_excerpt($post_id)) . '</p>';
	}
	echo '</div></section>';
}

/**
 * Heading and paragraph pairs from a page.
 *
 * @param int $post_id Post ID.
 * @return array<int, array{title: string, text: string}>
 */
function hohorizon_pairs($post_id) {
	$post = get_post($post_id);
	if (!$post) {
		return array();
	}
	$items   = array();
	$current = null;
	foreach (parse_blocks($post->post_content) as $block) {
		if ($block['blockName'] === 'core/heading') {
			if ($current) {
				$items[] = $current;
			}
			$current = array(
				'title' => trim(wp_strip_all_tags($block['innerHTML'])),
				'text'  => '',
			);
		} elseif ($block['blockName'] === 'core/paragraph' && $current) {
			$text = trim(wp_strip_all_tags($block['innerHTML']));
			if ($text !== '') {
				$current['text'] .= ($current['text'] === '' ? '' : ' ') . $text;
			}
		}
	}
	if ($current) {
		$items[] = $current;
	}
	return $items;
}

/**
 * Sample agenda rows used until sessions are published.
 */
function hohorizon_sample_sessions() {
	$rows = array(
		array('leadership', 'Opening conversation', 'How the day will be used, and what a useful disagreement looks like.'),
		array('finance', 'Capital across borders', 'Where cross-border finance is slowing, and where it is still moving.'),
		array('investment', 'Mandates, not slogans', 'What investors are actually willing to underwrite this year.'),
		array('trade', 'Routes and resilience', 'Trade corridors, delays, and the contracts written around them.'),
	);
	foreach ($rows as $row) {
		echo '<article class="session" data-topic="' . esc_attr($row[0]) . '">';
		echo '<p>Time to be confirmed<br />Duration to be confirmed</p>';
		echo '<div><h3>' . esc_html($row[1]) . '</h3><p>' . esc_html($row[2]) . '</p></div>';
		echo '<p>Speaker to be confirmed<br />Designation to be confirmed</p>';
		echo '</article>';
	}
}
function hohorizon_session_row() {
	$topic = get_post_meta(get_the_ID(), '_hohorizon_topic', true);
	$time  = get_post_meta(get_the_ID(), '_hohorizon_time', true);
	$span  = get_post_meta(get_the_ID(), '_hohorizon_duration', true);
	$who   = get_post_meta(get_the_ID(), '_hohorizon_speaker', true);
	$role  = get_post_meta(get_the_ID(), '_hohorizon_role', true);
	echo '<article class="session" data-topic="' . esc_attr($topic) . '">';
	echo '<p>' . esc_html($time) . '<br />' . esc_html($span) . '</p>';
	echo '<div><h3>' . esc_html(get_the_title()) . '</h3><p>' . esc_html(wp_strip_all_tags(get_the_content())) . '</p></div>';
	echo '<p>' . esc_html($who) . '<br />' . esc_html($role) . '</p>';
	echo '</article>';
}

/**
 * Filter buttons for sessions.
 */
function hohorizon_filters() {
	echo '<div class="filters" aria-label="Filter sessions">';
	echo '<button type="button" data-filter="all" aria-pressed="true">All</button>';
	foreach (hohorizon_topics() as $key => $label) {
		echo '<button type="button" data-filter="' . esc_attr($key) . '">' . esc_html($label) . '</button>';
	}
	echo '</div>';
}

/**
 * Primary menu when none has been saved.
 */
function hohorizon_primary_fallback() {
	$items = array(
		array('Home', '', array()),
		array('About', 'about', array()),
		array('Conference', 'next-meet', array()),
		array('Speakers', 'speakers', array()),
		array('Contact', 'contact', array()),
	);
	foreach ($items as $item) {
		$url = $item[1] === '' ? home_url('/') : hohorizon_page_url($item[1]);
		$anchors = array(
			'About'      => '#about',
			'Conference' => '#next-meet',
			'Speakers'   => '#speakers',
			'Partners'   => '#partners',
			'Contact'    => '#contact',
		);
		if (isset($anchors[$item[0]])) {
			$url = home_url('/') . $anchors[$item[0]];
		}
		$href = isset($anchors[$item[0]]) ? esc_url(home_url('/')) . $anchors[$item[0]] : esc_url($url);
		echo '<div class="menu-item"><a href="' . $href . '">' . hohorizon_nav_icon($item[0]) . esc_html($item[0]) . '</a>';
		if ($item[2]) {
			echo '<div class="dropdown">';
			foreach ($item[2] as $child) {
				echo '<a href="' . esc_url(hohorizon_page_url($child[1])) . '">' . hohorizon_nav_icon($child[0]) . esc_html($child[0]) . '</a>';
			}
			echo '</div>';
		}
		echo '</div>';
	}
}

/**
 * Footer quick links fallback.
 */
function hohorizon_footer_quick_fallback() {
	hohorizon_link_list(
		array(
			'About Us'             => 'about',
			'Conference'           => '#next-meet',
			'Contact'              => '#contact',
			'Privacy Policy'       => 'privacy',
			'Terms & Conditions'   => 'terms',
		)
	);
}

/**
 * Footer explore links fallback.
 */
function hohorizon_footer_explore_fallback() {
	hohorizon_link_list(
		array(
			'Conference'             => '#next-meet',
			'Programme'              => 'programme',
			'Speakers'               => 'speakers',
			'Partners'               => '#partners',
			'Become a Partner'       => 'become-a-partner',
			'Request an invitation'  => '#contact',
		)
	);
}

/**
 * A simple link list.
 *
 * @param array<string, string> $links Label => slug.
 */
function hohorizon_link_list($links) {
	echo '<ul>';
	foreach ($links as $label => $slug) {
		$href = (isset($slug[0]) && $slug[0] === '#') ? home_url('/') . $slug : hohorizon_page_url($slug);
		echo '<li><a href="' . esc_url($href) . '">' . hohorizon_menu_icon($label) . esc_html($label) . '</a></li>';
	}
	echo '</ul>';
}

/**
 * Point a saved menu link at the current site when it still uses the old domain.
 *
 * @param string $url Stored URL.
 * @return string
 */
function hohorizon_rewrite_legacy_url($url) {
	if (!is_string($url) || $url === '') {
		return $url;
	}
	$host = wp_parse_url($url, PHP_URL_HOST);
	if (!$host || strcasecmp($host, 'horizonglobalaffairs.com') !== 0) {
		return $url;
	}
	$path     = wp_parse_url($url, PHP_URL_PATH);
	$query    = wp_parse_url($url, PHP_URL_QUERY);
	$fragment = wp_parse_url($url, PHP_URL_FRAGMENT);
	$rebuilt  = untrailingslashit(home_url('/'));
	if (is_string($path) && $path !== '' && $path !== '/') {
		$rebuilt .= '/' . ltrim($path, '/');
	} else {
		$rebuilt .= '/';
	}
	if (is_string($query) && $query !== '') {
		$rebuilt .= '?' . $query;
	}
	if (is_string($fragment) && $fragment !== '') {
		$rebuilt .= '#' . $fragment;
	}
	return $rebuilt;
}

/**
 * Rewrite old-domain links in every saved menu.
 *
 * @param array<int, WP_Post> $items Menu items.
 * @return array<int, WP_Post>
 */
function hohorizon_rewrite_legacy_menu_urls($items) {
	$kept = array();
	foreach ($items as $item) {
		$title = strtolower(trim(wp_strip_all_tags($item->title)));
		$url = isset($item->url) ? $item->url : '';
		if ($title === 'agenda' || $title === 'media' || $title === 'our mission' || $title === 'membership' || $title === 'events' || strpos($url, '#agenda') !== false || strpos($url, '#media') !== false) {
			continue;
		}
		$anchors = array(
			'contact'  => '#contact',
			'partners' => '#partners',
			'about'    => '#about',
			'about us' => '#about',
		);
		if (isset($anchors[$title])) {
			$item->url = home_url('/') . $anchors[$title];
		} elseif ($url !== '') {
			$item->url = hohorizon_rewrite_legacy_url($url);
		}
		$kept[] = $item;
	}
	$has_about = false;
	foreach ($kept as $item) {
		$label = strtolower(trim(wp_strip_all_tags($item->title)));
		if ($label === 'about' || $label === 'about us') {
			$has_about = true;
		}
	}
	if (!$has_about) {
		$about          = new stdClass();
		$about->title   = 'About';
		$about->url     = home_url('/') . '#about';
		$about->classes = array();
		array_splice($kept, min(1, count($kept)), 0, array($about));
	}
	$has_conference = false;
	foreach ($kept as $item) {
		$label = strtolower(trim(wp_strip_all_tags($item->title)));
		if ($label === 'conference') {
			$has_conference = true;
			$item->url      = home_url('/') . '#next-meet';
		}
	}
	if (!$has_conference) {
		$conference             = new stdClass();
		$conference->title      = 'Conference';
		$conference->url        = home_url('/') . '#next-meet';
		$conference->classes    = array();
		$conference->ID         = 0;
		$conference->attr_title = '';
		$conference->target     = '';
		$conference->xfn            = '';
		$conference->menu_item_parent = 0;
		$insert                 = 1;
		foreach ($kept as $index => $item) {
			$label = strtolower(trim(wp_strip_all_tags($item->title)));
			if ($label === 'about' || $label === 'about us') {
				$insert = $index + 1;
				break;
			}
		}
		array_splice($kept, min($insert, count($kept)), 0, array($conference));
	}
	return $kept;
}
add_filter('wp_nav_menu_objects', 'hohorizon_rewrite_legacy_menu_urls');

/**
 * Menu URL. About, Agenda, Speakers and Media stay on the homepage.
 *
 * @param string $title Menu label.
 * @param string $url Stored URL.
 * @param int    $depth Depth.
 * @return string
 */
function hohorizon_nav_href($title, $url, $depth = 0) {
	$anchors = array(
		'about'      => '#about',
		'about us'   => '#about',
		'conference' => '#next-meet',
		'speakers'   => '#speakers',
		'partners'   => '#partners',
		'contact'    => '#contact',
	);
	$key = strtolower(trim(wp_strip_all_tags($title)));
	if ((int) $depth === 0 && $key === 'home') {
		return esc_url(home_url('/'));
	}
	if ((int) $depth === 0 && isset($anchors[$key])) {
		return esc_url(home_url('/')) . $anchors[$key];
	}
	return esc_url(hohorizon_rewrite_legacy_url($url));
}

/**
 * Menu markup that matches the existing stylesheet.
 */
class Hohorizon_Walker extends Walker_Nav_Menu {
	/**
	 * Open a submenu.
	 *
	 * @param string   $output Output.
	 * @param int      $depth Depth.
	 * @param stdClass $args Args.
	 */
	public function start_lvl(&$output, $depth = 0, $args = null) {
	}

	/**
	 * Close a submenu.
	 *
	 * @param string   $output Output.
	 * @param int      $depth Depth.
	 * @param stdClass $args Args.
	 */
	public function end_lvl(&$output, $depth = 0, $args = null) {
	}

	/**
	 * Open a menu item.
	 *
	 * @param string   $output Output.
	 * @param WP_Post  $item Item.
	 * @param int      $depth Depth.
	 * @param stdClass $args Args.
	 * @param int      $id ID.
	 */
	public function start_el(&$output, $item, $depth = 0, $args = null, $id = 0) {
		if ($depth > 0) {
			return;
		}
		$classes = empty($item->classes) ? array() : (array) $item->classes;
		$active  = in_array('current-menu-item', $classes, true) || in_array('current-menu-ancestor', $classes, true);
		if ($depth === 0) {
			$output .= '<div class="menu-item">';
		}
		$output .= '<a href="' . hohorizon_nav_href($item->title, $item->url, $depth) . '"' . ($active ? ' aria-current="page"' : '') . '>' . hohorizon_nav_icon($item->title) . esc_html($item->title) . '</a>';
	}

	/**
	 * Close a menu item.
	 *
	 * @param string   $output Output.
	 * @param WP_Post  $item Item.
	 * @param int      $depth Depth.
	 * @param stdClass $args Args.
	 */
	public function end_el(&$output, $item, $depth = 0, $args = null) {
		if ($depth > 0) {
			return;
		}
		if ($depth === 0) {
			$output .= '</div>';
		}
	}
}

/**
 * The conference calendar. Edit this list to change the tiles on the homepage and the Events page.
 *
 * @return array<int, array<string, string>>
 */
function hohorizon_conferences() {
	return array(
		array(
			'name'     => 'GCC Tax Leadership Summit & Awards 2027',
			'location' => 'Dubai, United Arab Emirates',
			'month'    => 'March 2027',
			'region'   => 'GCC',
			'image'    => 'https://images.unsplash.com/photo-1512453979798-5ea266f8880c?auto=format&fit=crop&w=1000&q=80',
			'alt'      => 'Dubai skyline at sunset',
		),
		array(
			'name'     => 'European Tax Leadership Summit & Awards 2027 - Viva La ViDA',
			'location' => 'Madrid, Spain',
			'month'    => 'May 2027',
			'region'   => 'Europe',
			'image'    => 'https://images.unsplash.com/photo-1539037116277-4db20889f2d4?auto=format&fit=crop&w=1000&q=80',
			'alt'      => 'Madrid\'s Gran Vía at dusk',
		),
		array(
			'name'     => 'APAC CFO Assembly & Awards 2027',
			'location' => 'India',
			'month'    => 'July 2027',
			'region'   => 'APAC',
			'image'    => 'https://images.unsplash.com/photo-1587474260584-136574528ed5?auto=format&fit=crop&w=1000&q=80',
			'alt'      => 'India Gate in New Delhi at dawn',
		),
		array(
			'name'     => '2nd APAC CFO Assembly & Awards 2027',
			'location' => 'India',
			'month'    => 'September 2027',
			'region'   => 'APAC',
			'image'    => 'https://images.unsplash.com/photo-1524492412937-b28074a5d7da?auto=format&fit=crop&w=1000&q=80',
			'alt'      => 'The Taj Mahal reflected in its pool',
		),
		array(
			'name'     => 'GCC CFO Assembly & Awards 2027',
			'location' => 'United Arab Emirates',
			'month'    => 'November 2027',
			'region'   => 'GCC',
			'image'    => 'https://images.unsplash.com/photo-1518684079-3c830dcef090?auto=format&fit=crop&w=1000&q=80',
			'alt'      => 'Aerial view of the Dubai coastline',
		),
	);
}

/**
 * Conference tiles.
 */
function hohorizon_conference_cards() {
	$pin   = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 21s7-6.2 7-11a7 7 0 1 0-14 0c0 4.8 7 11 7 11z"/><circle cx="12" cy="10" r="2.5"/></svg>';
	$cal   = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4"/></svg>';
	$arrow = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12h14M13 6l6 6-6 6"/></svg>';
	foreach (hohorizon_conferences() as $c) {
		$parts = explode(' ', $c['month']);
		$short = substr($parts[0], 0, 3);
		$year  = isset($parts[1]) ? $parts[1] : '';
		echo '<article class="conf-card">';
		echo '<div class="conf-media">';
		echo '<img src="' . esc_url($c['image']) . '" alt="' . esc_attr($c['alt']) . '" loading="lazy" />';
		echo '<span class="conf-date"><strong>' . esc_html($short) . '</strong>' . esc_html($year) . '</span>';
		echo '<span class="conf-region">' . esc_html($c['region']) . '</span>';
		echo '</div><div class="conf-body">';
		echo '<h3>' . esc_html($c['name']) . '</h3>';
		echo '<ul class="conf-meta"><li>' . $pin . esc_html($c['location']) . '</li><li>' . $cal . esc_html($c['month']) . '</li></ul>';
		echo '<a class="conf-link" href="' . esc_url(home_url('/#contact')) . '">Request invitation' . $arrow . '</a>';
		echo '</div></article>';
	}
}

/**
 * Event cards: the conference calendar as a grid.
 *
 * @param int $count Unused. Kept so older template calls still work.
 */
function hohorizon_event_list($count = -1) {
	echo '<div class="conf-grid">';
	hohorizon_conference_cards();
	echo '</div>';
}

/**
 * Speakers page: two scrolling portrait rows.
 */
function hohorizon_speaker_stage($tag = 'h1', $home = false) {
	$speakers = hohorizon_query('hoh_speaker', -1);
	$cards    = array();
	$fallbacks = array(
		'https://images.unsplash.com/photo-1560250097-0b93528c311a?auto=format&fit=crop&w=600&q=80',
		'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=600&q=80',
		'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=crop&w=600&q=80',
		'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=600&q=80',
		'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&w=600&q=80',
		'https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&w=600&q=80',
		'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=600&q=80',
		'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?auto=format&fit=crop&w=600&q=80',
		'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&w=600&q=80',
		'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=600&q=80',
		'https://images.unsplash.com/photo-1573497019940-1c28c88b4f3e?auto=format&fit=crop&w=600&q=80',
		'https://images.unsplash.com/photo-1556157382-97eda2d62296?auto=format&fit=crop&w=600&q=80',
	);
	$index = 0;
	if ($speakers->have_posts()) {
		while ($speakers->have_posts()) {
			$speakers->the_post();
			$image = get_the_post_thumbnail_url(get_the_ID(), 'medium_large');
			if (!$image) {
				$image = $fallbacks[$index % count($fallbacks)];
			}
			$role = (string) get_post_meta(get_the_ID(), '_hohorizon_role', true);
			$bio  = wp_strip_all_tags(get_the_content());
			$cards[] = array(get_the_ID(), get_the_title(), $role !== '' ? $role : 'Role to be confirmed', $image, $bio);
			$index++;
		}
		wp_reset_postdata();
	}
	$sample = 0;
	while (count($cards) < 14) {
		$cards[] = array(
			'sample-' . $sample,
			'Name to be confirmed',
			'Title to be confirmed',
			$fallbacks[$sample % count($fallbacks)],
			'A short biography will be published here after the speaker agrees to appear.',
		);
		$sample++;
	}
	$tag = $tag === 'h2' ? 'h2' : 'h1';
	echo '<section class="speaker-stage' . ($home ? ' is-home' : '') . '"' . ($home ? ' id="speakers"' : '') . '>';
	echo '<div class="wrap speaker-intro"><' . $tag . ' class="meet">Meet the Speakers</' . $tag . '>';
	echo '<p>Senior executives and industry experts sharing firsthand perspectives on global trade, finance, AI, logistics, risk and technology.</p></div>';
	if (!$cards) {
		echo '<p class="lede wrap">No speaker profiles have been published yet.</p></section>';
		return;
	}
	$rows = array_chunk($cards, (int) ceil(count($cards) / 2));
	if (count($rows) === 1) {
		$rows[] = $rows[0];
	}
	foreach ($rows as $row) {
		echo '<div class="portrait-row"><button class="portrait-arrow" type="button" data-dir="-1" aria-label="Previous speakers"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M14 6 8 12l6 6" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg></button><div class="portrait-window"><div class="portrait-track">';
		foreach ($row as $card) {
			echo '<article class="portrait" id="speaker-' . esc_attr((string) $card[0]) . '">';
			echo '<img src="' . esc_url($card[3]) . '" alt="" />';
			echo '<button class="portrait-more" type="button" aria-expanded="false" aria-label="Sample profile">+</button>';
			echo '<div class="portrait-copy"><h3>' . esc_html($card[1]) . '</h3><p>' . esc_html($card[2]) . '</p></div>';
			echo '<p class="portrait-bio">' . esc_html($card[4]) . '</p></article>';
		}
		echo '</div></div><button class="portrait-arrow" type="button" data-dir="1" aria-label="Next speakers"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M10 6l6 6-6 6" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg></button></div>';
	}
	echo '</section>';
}

/**
 * Speaker cards.
 *
 * @param int  $count How many. -1 for all.
 * @param bool $link Whether to link to the speakers page.
 */
function hohorizon_speaker_list($count = -1, $link = false) {
	$speakers = hohorizon_query('hoh_speaker', $count);
	if (!$speakers->have_posts()) {
		echo '<p class="lede">No speaker profiles have been published yet.</p>';
		return;
	}
	echo '<div class="speakers">';
	$number = 1;
	while ($speakers->have_posts()) {
		$speakers->the_post();
		$image = get_the_post_thumbnail_url(get_the_ID(), 'medium');
		$note  = get_post_meta(get_the_ID(), '_hohorizon_note', true);
		echo '<article class="speaker" id="speaker-' . esc_attr((string) get_the_ID()) . '">';
		echo '<div class="monogram" aria-hidden="true">';
		if ($image) {
			echo '<img src="' . esc_url($image) . '" alt="" />';
		} else {
			echo esc_html(str_pad((string) $number, 2, '0', STR_PAD_LEFT));
		}
		echo '</div>';
		echo '<h3>' . esc_html(get_the_title()) . '</h3>';
		echo '<p>' . esc_html((string) get_post_meta(get_the_ID(), '_hohorizon_role', true)) . '</p>';
		echo '<p>' . esc_html((string) get_post_meta(get_the_ID(), '_hohorizon_organisation', true)) . '</p>';
		if (!$link) {
			echo '<p>' . esc_html(wp_strip_all_tags(get_the_content())) . '</p>';
		}
		if ($note) {
			echo '<p class="note">' . esc_html($note) . '</p>';
		}
		if ($link) {
			echo '<a class="btn btn-ink" href="' . esc_url(hohorizon_page_url('speakers') . '#speaker-' . get_the_ID()) . '">View profile</a>';
		}
		echo '</article>';
		$number++;
	}
	echo '</div>';
	wp_reset_postdata();
}

/**
 * Logo tiles. Empty places stay labelled until a logo is added.
 *
 * @param int    $count How many. 0 lists the whole tier.
 * @param string $tier Optional tier key.
 */
function hohorizon_partner_row($count = 0, $tier = '') {
	$meta = array();
	if ($tier !== '') {
		$meta[] = array(
			'key'   => '_hohorizon_tier',
			'value' => $tier,
		);
	}
	$partners = hohorizon_query('hoh_partner', $count > 0 ? $count : -1, $meta);
	echo '<div class="logo-row">';
	if ($partners->have_posts()) {
		while ($partners->have_posts()) {
			$partners->the_post();
			$logo = get_the_post_thumbnail_url(get_the_ID(), 'medium');
			echo '<div class="logo-tile">';
			if ($logo) {
				echo '<img src="' . esc_url($logo) . '" alt="' . esc_attr(get_the_title()) . '" />';
			} else {
				echo esc_html(get_the_title());
			}
			echo '</div>';
		}
		wp_reset_postdata();
	} else {
		$slots = $count > 0 ? $count : 4;
		for ($i = 0; $i < $slots; $i++) {
			echo '<div class="logo-tile">Logo to add</div>';
		}
	}
	echo '</div>';
}

/**
 * Stroke icon markup for a menu label.
 *
 * @param string $label Link label.
 * @return string
 */
function hohorizon_menu_icon($label) {
	$key = strtolower(trim(wp_strip_all_tags($label)));
	$map = array(
		'home'                  => 'home',
		'about'                 => 'about',
		'about us'              => 'about',
		'conference'            => 'conference',
		'our mission'           => 'mission',
		'agenda'                => 'programme',
		'programme'             => 'programme',
		'speakers'              => 'speakers',
		'partners'              => 'partners',
		'media'                 => 'events',
		'events'                => 'events',
		'contact'               => 'contact',
		'contact us'            => 'contact',
		'membership'            => 'membership',
		'privacy policy'        => 'privacy',
		'terms & conditions'    => 'terms',
		'terms and conditions'  => 'terms',
		'become a partner'      => 'partner',
		'request an invitation' => 'contact',
		'request an invite'     => 'contact',
		'email'                 => 'contact',
		'address'               => 'pin',
		'business hours'        => 'clock',
		'mobile'                => 'phone',
	);
	$paths = array(
		'home'       => '<path d="M4 10.5 12 4l8 6.5V20a1 1 0 0 1-1 1h-5v-6H10v6H5a1 1 0 0 1-1-1z"/>',
		'about'      => '<circle cx="12" cy="8" r="3"/><path d="M5 19c1.2-3 3.4-4.5 7-4.5S17.8 16 19 19"/>',
		'conference' => '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M8 3v4M16 3v4M7 11h10M12 11v5"/>',
		'programme'  => '<rect x="4" y="5" width="16" height="15" rx="2"/><path d="M8 3v4M16 3v4M4 10h16"/>',
		'speakers'   => '<rect x="9" y="3" width="6" height="10" rx="3"/><path d="M6 11a6 6 0 0 0 12 0M12 17v4M8 21h8"/>',
		'partners'   => '<circle cx="8" cy="9" r="2.4"/><circle cx="16" cy="9" r="2.4"/><path d="M3.5 18.5c.7-2.4 2.3-3.5 4.5-3.5s3.8 1.1 4.5 3.5M11.5 18.5c.7-2.4 2.3-3.5 4.5-3.5s3.8 1.1 4.5 3.5"/>',
		'events'     => '<rect x="3" y="6" width="18" height="12" rx="2"/><path d="m10 9 5 3-5 3z"/>',
		'contact'    => '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="m4 7 8 6 8-6"/>',
		'pin'        => '<path d="M12 21s7-6.2 7-11a7 7 0 1 0-14 0c0 4.8 7 11 7 11z"/><circle cx="12" cy="10" r="2.5"/>',
		'clock'      => '<circle cx="12" cy="12" r="8"/><path d="M12 8v5l3 2"/>',
		'phone'      => '<path d="M8 4h3l1.4 3.4-1.8 1.1a11 11 0 0 0 4.9 4.9l1.1-1.8L21 13v3a2 2 0 0 1-2.2 2A16 16 0 0 1 6 5.2 2 2 0 0 1 8 4z"/>',
		'mission'    => '<circle cx="12" cy="12" r="8"/><path d="M12 8v4l3 2"/>',
		'membership' => '<rect x="3" y="6" width="18" height="12" rx="2"/><path d="M3 10h18"/>',
		'partner'    => '<path d="M12 5v14M5 12h14"/>',
		'privacy'    => '<path d="M12 3 5 6v6c0 4.2 2.8 7.2 7 8.5 4.2-1.3 7-4.3 7-8.5V6z"/>',
		'terms'      => '<path d="M7 3h7l5 5v13H7z"/><path d="M14 3v5h5M9 13h6M9 17h6"/>',
	);
	$id = isset($map[$key]) ? $map[$key] : 'home';
	return '<svg class="nav-icon" viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round">' . $paths[$id] . '</svg>';
}

/**
 * Social icon markup.
 *
 * @param string $id Icon id.
 * @return string
 */
function hohorizon_social_icon($id) {
	$paths = array(
		'linkedin'  => '<rect x="3" y="3" width="18" height="18" rx="2"/><path d="M8 10v7M8 7h.01M12 17v-4.2a2 2 0 0 1 4 0V17"/>',
		'instagram' => '<rect x="4" y="4" width="16" height="16" rx="4"/><circle cx="12" cy="12" r="3.5"/><path d="M17.5 6.5h.01"/>',
		'youtube'   => '<rect x="3" y="6" width="18" height="12" rx="3"/><path d="m10 9 5 3-5 3z"/>',
		'facebook'  => '<path d="M14 8h2V5h-2a3 3 0 0 0-3 3v2H9v3h2v6h3v-6h2.2l.8-3H14V8a1 1 0 0 1 1-1z"/>',
	);
	$path = isset($paths[$id]) ? $paths[$id] : $paths['linkedin'];
	return '<svg class="nav-icon" viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round">' . $path . '</svg>';
}

/**
 * Add icons to the footer menus.
 *
 * @param string   $title Title.
 * @param WP_Post  $item Item.
 * @param stdClass $args Args.
 * @param int      $depth Depth.
 * @return string
 */
function hohorizon_footer_menu_icon($title, $item, $args, $depth) {
	unset($item, $depth);
	$location = isset($args->theme_location) ? $args->theme_location : '';
	if (!in_array($location, array('footer_quick', 'footer_explore'), true)) {
		return $title;
	}
	return hohorizon_menu_icon($title) . esc_html(wp_strip_all_tags($title));
}
add_filter('nav_menu_item_title', 'hohorizon_footer_menu_icon', 10, 4);
